/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import model.CartItemDAO;
import model.CartItemDTO;
import model.OrderDAO;
import model.OrderDTO;
import model.OrderDetailDAO;
import model.OrderDetailDTO;
import model.UserDTO;
import utils.AuthUtils;
import utils.Email;

/**
 *
 * @author Admin
 */
@WebServlet(name = "OrderController", urlPatterns = {"/OrderController"})
public class OrderController extends HttpServlet {

    OrderDAO orderDAO = new OrderDAO();
    CartItemDAO cartItemDAO = new CartItemDAO();

    private static final String CHECKOUT_PAGE = "checkout.jsp";
    private static final String ORDER_HISTORY_PAGE = "orderHistory.jsp";
    private static final String ORDER_DETAIL_PAGE = "orderDetail.jsp";
    private static final String ERROR_PAGE = "error.jsp";
    private static final String CART_PAGE = "cartBuying.jsp";
    private static final String CONFIRMATION_PAGE = "orderConfirmation.jsp";
    private static final String PAYMENT_CONFIRMATION_PAGE = "paymentConfirmation.jsp";
    private static final String REFUND_NOTIFICATION_PAGE = "refundNotification.jsp";
    private static final String ORDER_LIST_PAGE = "orderList.jsp";
    private static final String ORDER_FORM_PAGE = "orderForm.jsp";

    public static final String STATUS_PROCESSING = "Đang xử lý";
    public static final String STATUS_CONFIRMED = "Đã xác nhận";
    public static final String STATUS_PAID = "Đã thanh toán";
    public static final String STATUS_COMPLETED = "Hoàn tất";
    public static final String STATUS_CANCELLED = "Đã hủy";
    public static final String STATUS_REFUND_REQUESTED = "Yêu cầu hoàn tiền";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR_PAGE;
        try {
            String action = request.getParameter("action");
            if (action == null) {
                action = "";
            }

            Boolean isLoggedIn = AuthUtils.isLoggedIn(request);
            if (isLoggedIn == null || !isLoggedIn) {
                url = "login.jsp";
            } else if (action.isEmpty() || action.equals("viewCheckout")) {
                url = handleViewCheckout(request, response);
            } else if (action.equals("checkout")) {
                url = handleCheckout(request, response);
                if (url == null) {
                    return;
                }
            } else if (action.equals("viewOrderHistory")) {
                url = handleViewOrderHistory(request, response);
            } else if (action.equals("viewOrderDetail")) {
                url = handleViewOrderDetail(request, response);
            } else if (action.equals("verifyPayment")) {
                url = handleVerifyPayment(request, response);
            } else if (action.equals("confirm")) {
                url = handleConfirmOrder(request, response);
            } else if (action.equals("viewCheckout")) {
                url = handleViewCheckout(request, response);
            } else if (action.equals("processPayment")) {
                url = handleProcessPayment(request, response);
            } else if (action.equals("cancelOrder")) {
                url = handleCancelOrder(request, response);
            } else if (action.equals("requestRefund")) {
                url = handleRequestRefund(request, response);
            } else if (action.equals("viewOrders")) {
                url = handleViewOrders(request, response);
            } else if (action.equals("editOrder")) {
                url = handleEditOrder(request, response);
            } else if (action.equals("updateOrder")) {
                url = handleUpdateOrder(request, response);
            } else if (action.equals("deleteOrder")) {
                url = handleDeleteOrder(request, response);
            } else if (action.equals("processRefund")) {
                url = handleProcessRefund(request, response);
            } else {
                request.setAttribute("errorMessage", "Hành động không hợp lệ!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
        } finally {
            if (url != null) {
                RequestDispatcher rd = request.getRequestDispatcher(url);
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleViewCheckout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        try {
            List<CartItemDTO> cartItems = cartItemDAO.getCartItems(user.getUser_id());
            double totalPrice = cartItemDAO.getTotalPrice(user.getUser_id());

            if (cartItems.isEmpty()) {
                request.setAttribute("errorMessage", "Giỏ hàng trống. Vui lòng thêm sản phẩm trước khi thanh toán");
                return CART_PAGE;
            }

            request.setAttribute("cartItems", cartItems);
            request.setAttribute("totalPrice", totalPrice);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading products: " + e.getMessage());
        }
        return CHECKOUT_PAGE;
    }

    private String handleCheckout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);

        if (session == null) {
            request.setAttribute("errorMessage", "Session hết hạn. Vui lòng đăng nhập lại");
            return "login.jsp";
        }

        UserDTO user = (UserDTO) session.getAttribute("user");
        if (user == null) {
            request.setAttribute("errorMessage", "Session hết hạn. Vui lòng đăng nhập lại");
            return "login.jsp";
        }

        try {
            String paymentMethod = request.getParameter("paymentMethod");
            String shippingMethod = request.getParameter("shippingMethod");

            if (paymentMethod == null || shippingMethod == null) {
                request.setAttribute("errorMessage", "Thiếu thông tin thanh toán hoặc vận chuyển");
                return CHECKOUT_PAGE;
            }

            double shippingFee;
            try {
                shippingFee = Double.parseDouble(request.getParameter("shippingFee"));
            } catch (NumberFormatException e) {
                shippingFee = 22200;
            }

            List<CartItemDTO> cartItems = cartItemDAO.getCartItems(user.getUser_id());
            double totalPrice = cartItemDAO.getTotalPrice(user.getUser_id());
            double totalAmount = totalPrice + shippingFee;

            request.setAttribute("cartItems", cartItems);
            request.setAttribute("totalPrice", totalPrice);
            request.setAttribute("shippingFee", shippingFee);
            request.setAttribute("totalAmount", totalAmount);

            if (cartItems.isEmpty()) {
                request.setAttribute("errorMessage", "Giỏ hàng trống. Vui lòng thêm sản phẩm trước khi thanh toán");
                return CART_PAGE;
            }

            OrderDTO order = new OrderDTO(user.getUser_id(),
                    "Đang xử lý",
                    totalAmount,
                    paymentMethod);
            order.setShipping_method(shippingMethod);
            order.setShipping_fee(shippingFee);

            int orderId = orderDAO.createOrder(order, cartItems);

            if (orderId > 0) {
                session.setAttribute("currentOrderId", orderId);
                session.setAttribute("currentOrderTotal", totalAmount);
                session.setAttribute("currentOrderShippingFee", shippingFee);
                session.setAttribute("currentOrderPaymentMethod", paymentMethod);
                session.setAttribute("currentOrderShippingMethod", shippingMethod);

                OrderDTO createdOrder = orderDAO.getOrderById(orderId);
                List<OrderDetailDTO> orderDetails = orderDAO.getOrderDetails(orderId);

                Email.sendOrderConfirmationEmail(user.getEmail(), createdOrder, orderDetails);

                if ("COD".equals(paymentMethod)) {
                    orderDAO.updateOrderStatus(orderId, "Đã xác nhận");

                    request.setAttribute("orderId", orderId);
                    request.setAttribute("totalPrice", totalPrice);
                    request.setAttribute("shippingFee", shippingFee);
                    request.setAttribute("shippingMethod", shippingMethod);
                    request.setAttribute("paymentMethod", paymentMethod);

                    return CONFIRMATION_PAGE;
                } else {
                    return PAYMENT_CONFIRMATION_PAGE;
                }
            } else {
                request.setAttribute("errorMessage", "Có lỗi xảy ra khi đặt hàng. Vui lòng thử lại");
                return CHECKOUT_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xử lý thanh toán: " + e.getMessage());
            return CHECKOUT_PAGE;
        }
    }

    private String handleViewOrderHistory(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (user == null) {
            request.setAttribute("errorMessage", "Vui lòng đăng nhập để xem lịch sử đơn hàng.");
            return "login.jsp";
        }

        try {
            List<OrderDTO> orders = orderDAO.getOrdersByUser(user.getUser_id());
            request.setAttribute("orders", orders);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi lấy lịch sử đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
        return ORDER_HISTORY_PAGE;
    }

    private String handleViewOrderDetail(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (user == null) {
            request.setAttribute("errorMessage", "Vui lòng đăng nhập để xem chi tiết đơn hàng.");
            return "login.jsp";
        }

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));

            OrderDTO order = orderDAO.getOrderById(orderId);
            List<OrderDetailDTO> orderDetails = orderDAO.getOrderDetails(orderId);

            if (order != null) {

                if (order.getUser_id() != user.getUser_id()) {
                    request.setAttribute("errorMessage", "Bạn không có quyền xem đơn hàng này");
                    return ORDER_HISTORY_PAGE;
                }

                order.setOrderDetails(orderDetails);
                request.setAttribute("order", order);
                return ORDER_DETAIL_PAGE;
            } else {
                request.setAttribute("errorMessage", "Không tìm thấy đơn hàng");
                return ORDER_HISTORY_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xem chi tiết đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleVerifyPayment(HttpServletRequest request, HttpServletResponse response) {
        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            String paymentMethod = request.getParameter("paymentMethod");

            boolean success = orderDAO.updateOrderStatus(orderId, "Đã thanh toán");

            if (success) {
                HttpSession session = request.getSession();

                OrderDTO order = orderDAO.getOrderById(orderId);
                List<OrderDetailDTO> orderDetails = orderDAO.getOrderDetails(orderId);
                UserDTO user = (UserDTO) session.getAttribute("user");

                if (user != null) {
                    Email.sendOrderConfirmationEmail(user.getEmail(), order, orderDetails);
                }

                request.setAttribute("orderId", orderId);
                request.setAttribute("totalPrice", (Double) session.getAttribute("currentOrderTotal") - (Double) session.getAttribute("currentOrderShippingFee"));
                request.setAttribute("shippingFee", session.getAttribute("currentOrderShippingFee"));
                request.setAttribute("shippingMethod", session.getAttribute("currentOrderShippingMethod"));
                request.setAttribute("paymentMethod", paymentMethod);

                session.removeAttribute("currentOrderId");
                session.removeAttribute("currentOrderTotal");
                session.removeAttribute("currentOrderShippingFee");
                session.removeAttribute("currentOrderPaymentMethod");
                session.removeAttribute("currentOrderShippingMethod");

                return CONFIRMATION_PAGE;
            } else {
                request.setAttribute("errorMessage", "Xác nhận thanh toán không thành công");
                return ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xác nhận thanh toán: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleConfirmOrder(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        Integer orderId = (Integer) session.getAttribute("currentOrderId");

        if (orderId == null) {
            request.setAttribute("errorMessage", "Không tìm thấy đơn hàng để xác nhận");
            return CART_PAGE;
        }

        try {
            boolean updated = orderDAO.updateOrderStatus(orderId, "Đã xác nhận");

            if (updated) {
                request.setAttribute("orderId", orderId);
                request.setAttribute("totalPrice", (Double) session.getAttribute("currentOrderTotal") - (Double) session.getAttribute("currentOrderShippingFee"));
                request.setAttribute("shippingFee", session.getAttribute("currentOrderShippingFee"));
                request.setAttribute("shippingMethod", session.getAttribute("currentOrderShippingMethod"));
                request.setAttribute("paymentMethod", session.getAttribute("currentOrderPaymentMethod"));

                session.removeAttribute("currentOrderId");
                session.removeAttribute("currentOrderTotal");
                session.removeAttribute("currentOrderShippingFee");
                session.removeAttribute("currentOrderShippingMethod");
                session.removeAttribute("currentOrderPaymentMethod");

                return CONFIRMATION_PAGE;
            } else {
                request.setAttribute("errorMessage", "Không thể cập nhật trạng thái đơn hàng");
                return ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xác nhận đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleProcessPayment(HttpServletRequest request, HttpServletResponse response) {
        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            OrderDTO order = orderDAO.getOrderById(orderId);

            if (order != null) {
                HttpSession session = request.getSession();
                session.setAttribute("currentOrderId", orderId);
                session.setAttribute("currentOrderTotal", order.getTotal_amount());
                session.setAttribute("currentOrderPaymentMethod", order.getPayment_method());

                return PAYMENT_CONFIRMATION_PAGE;
            } else {
                request.setAttribute("errorMessage", "Không tìm thấy đơn hàng");
                return ORDER_HISTORY_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xử lý thanh toán: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleCancelOrder(HttpServletRequest request, HttpServletResponse response) {
        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            boolean success = orderDAO.updateOrderStatus(orderId, STATUS_CANCELLED);

            if (success) {
                request.setAttribute("successMessage", "Đơn hàng đã được hủy thành công");
                return "OrderController?action=viewOrderDetail&orderId=" + orderId;
            } else {
                request.setAttribute("errorMessage", "Không thể hủy đơn hàng");
                return "OrderController?action=viewOrderDetail&orderId=" + orderId;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi hủy đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleRequestRefund(HttpServletRequest request, HttpServletResponse response) {
        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            OrderDTO order = orderDAO.getOrderById(orderId);

            if (!STATUS_PAID.equals(order.getStatus())) {
                request.setAttribute("errorMessage", "Chỉ có thể yêu cầu hoàn tiền cho đơn hàng đã thanh toán");
                return "OrderController?action=viewOrderDetail&orderId=" + orderId;
            }

            boolean success = orderDAO.updateOrderStatus(orderId, STATUS_REFUND_REQUESTED);

            if (success) {
                request.setAttribute("successMessage", "Yêu cầu hoàn tiền đã được gửi. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất");
                return REFUND_NOTIFICATION_PAGE;
            } else {
                request.setAttribute("errorMessage", "Không thể gửi yêu cầu hoàn tiền");
                return "OrderController?action=viewOrderDetail&orderId=" + orderId;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi gửi yêu cầu hoàn tiền: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleViewOrders(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        try {
            OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            List<OrderDTO> orders = orderDetailDAO.getAllOrders();
            request.setAttribute("orders", orders);
            return ORDER_LIST_PAGE;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi tải đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleEditOrder(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            OrderDTO order = orderDetailDAO.getOrderById(orderId);

            if (order != null) {
                request.setAttribute("order", order);
                return ORDER_FORM_PAGE;
            } else {
                request.setAttribute("error", "Không tìm thấy đơn hàng");
                return ORDER_LIST_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi tải đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleUpdateOrder(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            String status = request.getParameter("status");

            OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            boolean success = orderDetailDAO.updateOrderStatus(orderId, status);

            if (success) {
                request.setAttribute("message", "Đơn hàng được cập nhật thành công");
            } else {
                request.setAttribute("error", "Không cập nhật được đơn hàng");
            }

            return handleViewOrders(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi cập nhật đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleDeleteOrder(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            boolean success = orderDetailDAO.deleteOrder(orderId);

            if (success) {
                request.setAttribute("message", "Đơn hàng đã được xóa thành công");
            } else {
                request.setAttribute("error", "Không xóa được đơn hàng");
            }

            return handleViewOrders(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi xóa đơn hàng: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleProcessRefund(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
            boolean success = orderDetailDAO.processRefund(orderId);

            if (success) {
                request.setAttribute("message", "Hoàn tiền được xử lý thành công");
            } else {
                request.setAttribute("error", "Không thể xử lý hoàn tiền");
            }

            return handleViewOrders(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi xử lý hoàn tiền: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

}
