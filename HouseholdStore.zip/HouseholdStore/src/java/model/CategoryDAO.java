/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class CategoryDAO {

    private static final String GET_ALL_CATEGORIES = "SELECT * FROM Categories";
    private static final String GET_CATEGORY_BY_ID = "SELECT * FROM Categories WHERE category_id = ?";
    private static final String CREATE_CATEGORY = "INSERT INTO Categories (name) VALUES (?)";
    private static final String UPDATE_CATEGORY = "UPDATE Categories SET name = ? WHERE category_id = ?";
    private static final String DELETE_CATEGORY = "DELETE FROM Categories WHERE category_id = ?";
    private static final String CHECK_CATEGORY_EXISTS = "SELECT 1 FROM Categories WHERE name = ?";

    public List<CategoryDTO> getAllCategories() throws SQLException {
        List<CategoryDTO> categories = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ALL_CATEGORIES);
            rs = ps.executeQuery();

            while (rs.next()) {
                CategoryDTO category = new CategoryDTO();
                category.setCategory_id(rs.getInt("category_id"));
                category.setName(rs.getString("name"));
                categories.add(category);
            }
        } catch (Exception e) {
            System.err.println("Error in getAllCategories(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return categories;
    }

    public CategoryDTO getCategoryById(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        CategoryDTO category = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_CATEGORY_BY_ID);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
                category = new CategoryDTO();
                category.setCategory_id(rs.getInt("category_id"));
                category.setName(rs.getString("name"));
            }
        } catch (Exception e) {
            System.err.println("Error in getCategoryById(): " + e.getMessage());
            e.printStackTrace();
        }finally {
            closeResources(conn, ps, rs);
        }
        return category;
    }

    public boolean createCategory(CategoryDTO category) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(CREATE_CATEGORY);
            ps.setString(1, category.getName());
            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in createCategory(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean updateCategory(CategoryDTO category) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(UPDATE_CATEGORY);
            ps.setString(1, category.getName());
            ps.setInt(2, category.getCategory_id());
            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in updateCategory(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean deleteCategory(int id) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(DELETE_CATEGORY);
            ps.setInt(1, id);
            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in deleteCategory(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean isCategoryExists(String name) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean exists = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(CHECK_CATEGORY_EXISTS);
            ps.setString(1, name);
            rs = ps.executeQuery();
            exists = rs.next();
        } catch (Exception e) {
            System.err.println("Error in isCategoryExists(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return exists;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
