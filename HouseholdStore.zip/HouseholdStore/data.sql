-- Tạo database
CREATE DATABASE HouseholdStore;
GO

USE HouseholdStore;
GO

-- Bảng Users (gộp Customer + Admin)
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) UNIQUE NOT NULL,
    password NVARCHAR(255) NOT NULL,
    fullname NVARCHAR(100),
    email NVARCHAR(100),
    phone NVARCHAR(20),
    address NVARCHAR(255),
    role NVARCHAR(10) NOT NULL, -- ADMIN hoặc USER
    created_at DATETIME DEFAULT GETDATE()
);

-- Bảng Categories
CREATE TABLE Categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL
);

-- Bảng Products
CREATE TABLE Products (
    product_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    description NVARCHAR(MAX),
    price DECIMAL(10,2),
    stock_quantity INT,
    category_id INT,
    image_url NVARCHAR(255),
    FOREIGN KEY (category_id) REFERENCES Categories(category_id)
);

-- Bảng Orders
CREATE TABLE Orders (
    order_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    order_date DATETIME DEFAULT GETDATE(),
    status NVARCHAR(50),
    total_amount DECIMAL(10,2),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

ALTER TABLE Orders ADD shipping_method NVARCHAR(50);
ALTER TABLE Orders ADD shipping_fee DECIMAL(10,2);
ALTER TABLE Orders ADD payment_method NVARCHAR(50);

-- Bảng OrderDetails
CREATE TABLE OrderDetails (
    order_detail_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Bảng CartItems
CREATE TABLE CartItems (
    cart_item_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    product_id INT,
    quantity INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Bảng ProductReviews
CREATE TABLE ProductReviews (
    review_id INT IDENTITY(1,1) PRIMARY KEY,
    product_id INT,
    user_id INT,
    rating INT,
    comment NVARCHAR(MAX),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (product_id) REFERENCES Products(product_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Dữ liệu mẫu Users
INSERT INTO Users (username, password, fullname, email, phone, address, role) VALUES
(N'vu.tran', N'hashed_password1', N'Vũ Trần', N'vu.tran@example.com', N'0909123456', N'HCM', N'USER'),
(N'nguyen.an', N'hashed_password2', N'Nguyễn An', N'nguyen.an@example.com', N'0912233445', N'Hà Nội', N'USER'),
(N'le.hoa', N'hashed_password3', N'Lê Hoa', N'le.hoa@example.com', N'0933344556', N'Đà Nẵng', N'USER'),
(N'pham.binh', N'hashed_password4', N'Phạm Bình', N'pham.binh@example.com', N'0944455667', N'Cần Thơ', N'USER'),
(N'admin', N'admin12345', N'Quản trị viên', NULL, NULL, NULL, N'ADMIN');

-- Dữ liệu mẫu Categories
INSERT INTO Categories (name) VALUES
(N'Điện gia dụng'),
(N'Đồ dùng nhà bếp'),
(N'Vệ sinh nhà cửa');
(N'Đồ dùng phòng tắm');

-- Dữ liệu mẫu Products
INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES
(N'Quạt đứng Panasonic', N'Quạt đứng tiết kiệm điện, 3 tốc độ gió', 1200000, 20, 1, N'images/1.jpg'),
(N'Nồi cơm điện Sharp', N'Nồi cơm điện 1.8L, chống dính', 950000, 15, 2, N'images/2.jpg'),
(N'Máy hút bụi Electrolux', N'Loại nhỏ gọn, công suất 1600W', 2100000, 10, 3, N'images/3.jpg'),
(N'Bình đun siêu tốc Philips', N'1.5 lít, tự ngắt', 450000, 30, 2, N'images/4.jpg'),
(N'Máy xay sinh tố Sunhouse', N'Đa năng, lưỡi thép không gỉ', 780000, 25, 2, N'images/5.jpg');
(N'Bếp từ đôi Sunhouse', N'2 vùng nấu, cảm ứng nhiệt', 3200000.00, 15, 2, N'images/6.jpg');

-- Thêm sản phẩm vào category 1 (Điện gia dụng)
INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES
(N'Máy lạnh Daikin 1HP', N'Máy lạnh inverter tiết kiệm điện', 8500000, 12, 1, N'images/7.jpg'),
(N'Bình nóng lạnh Ariston 15L', N'Bình nóng lạnh gián tiếp, an toàn', 3200000, 8, 1, N'images/8.jpg'),
(N'Đèn sưởi nhà tắm Kangaroo', N'Công suất 1200W, chống nước IPX4', 650000, 15, 1, N'images/9.jpg'),
(N'Quạt điều hòa Sunhouse', N'Quạt phun sương làm mát 3 chế độ', 1500000, 20, 1, N'images/10.jpg'),
(N'Máy lọc không khí Xiaomi', N'Lọc bụi mịn PM2.5, kết nối WiFi', 3500000, 10, 1, N'images/11.jpg');

-- Thêm sản phẩm vào category 2 (Đồ dùng nhà bếp)
INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES
(N'Lò vi sóng Sharp 20L', N'Lò vi sóng cơ, công suất 800W', 1200000, 18, 2, N'images/12.jpg'),
(N'Bộ nồi inox 3 lớp', N'Bộ 3 nồi inox cao cấp, chống dính', 950000, 25, 2, N'images/13.jpg'),
(N'Ấm đun nước thủy tinh', N'Ấm thủy tinh chịu nhiệt, dung tích 1.2L', 250000, 30, 2, N'images/14.jpg'),
(N'Chảo chống dính đá', N'Chảo đá chống dính cao cấp, đường kính 28cm', 450000, 22, 2, N'images/15.jpg'),
(N'Máy ép trái cây Philips', N'Máy ép tốc độ chậm, giữ nguyên vitamin', 1800000, 12, 2, N'images/16.jpg');

-- Thêm sản phẩm vào category 3 (Vệ sinh nhà cửa)
INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES
(N'Robot hút bụi Xiaomi', N'Robot lau nhà thông minh, kết nối app', 5000000, 8, 3, N'images/17.jpg'),
(N'Chổi lau nhà thông minh', N'Chổi xoay 360 độ, đầu bông mềm', 350000, 40, 3, N'images/18.jpg'),
(N'Bộ dụng cụ vệ sinh đa năng', N'Bộ 5 món: cây lau kính, bàn hút bụi...', 120000, 50, 3, N'images/19.jpg'),
(N'Máy hút bụi cầm tay', N'Công suất 600W, nhỏ gọn, hút mạnh', 850000, 15, 3, N'images/20.jpg'),
(N'Máy xịt cồn tự động Miken MKXC-B7960A', N'Máy xịt cồn tự động Miken MKXC-B7960A hoạt động đơn giản bằng chức năng cảm biến tự động hoàn toàn', 2600000, 20, 3, N'images/21.jpg'),

-- Thêm sản phẩm vào category 4 (Đồ dùng phòng tắm)
INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES
(N'Vòi sen tăng áp Inax', N'Vòi sen tăng áp 5 chế độ phun', 350000, 25, 4, N'images/22.jpg'),
(N'Bộ vệ sinh bồn cầu', N'Bộ cần gạt, bàn chải và giá đựng', 150000, 30, 4, N'images/23.jpg'),
(N'Giá để đồ phòng tắm', N'Giá inox không gỉ, 3 tầng', 220000, 20, 4, N'images/24.jpg'),
(N'Kệ đựng xà phòng dán tường', N'Chất liệu inox không gỉ, kèm keo dán, chịu lực tốt', 59000, 35, 4, N'images/25.jpg');

-- Dữ liệu mẫu Orders
INSERT INTO Orders (user_id, status, total_amount) VALUES
(1, N'Đang xử lý', 1200000),
(2, N'Hoàn tất', 3050000),
(3, N'Đang giao', 1230000);

-- Dữ liệu mẫu OrderDetails
INSERT INTO OrderDetails (order_id, product_id, quantity, price) VALUES
(1, 1, 1, 1200000),
(2, 1, 1, 1200000),
(2, 2, 1, 950000),
(2, 3, 1, 2100000),
(3, 4, 1, 450000),
(3, 5, 1, 780000);

-- Dữ liệu mẫu CartItems
INSERT INTO CartItems (user_id, product_id, quantity) VALUES
(1, 2, 2),
(1, 3, 1),
(3, 5, 1);

-- Dữ liệu mẫu ProductReviews
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(1, 1, 5, N'Quạt chạy êm, mát'),
(2, 2, 4, N'Nồi cơm nấu ngon nhưng hơi lâu'),
(3, 3, 5, N'Máy hút bụi mạnh và bền'),
(4, 4, 3, N'Bình đun ổn nhưng hơi ồn');
-- Thêm đánh giá dài cho sản phẩm 1 (Quạt đứng Panasonic)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(1, 2, 4, N'Tôi đã sử dụng quạt Panasonic này được 3 tháng và khá hài lòng. Ưu điểm: chạy êm, tiết kiệm điện, thiết kế đẹp. Nhược điểm: nút điều chỉnh hơi cứng và chân đế không chắc lắm khi di chuyển. Nhìn chung là sản phẩm tốt với mức giá này.');

-- Thêm đánh giá ngắn cho sản phẩm 2 (Nồi cơm điện Sharp)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(2, 3, 5, N'Nồi cơm ngon, dễ sử dụng!');

-- Thêm đánh giá trung bình cho sản phẩm 3 (Máy hút bụi Electrolux)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(3, 1, 3, N'Máy hút khá mạnh nhưng ồn hơn tôi tưởng. Dây điện ngắn nên phải dùng thêm ổ cắm di động. Đáng giá nếu bạn cần máy hút công suất cao giá tầm trung.');

-- Thêm đánh giá chi tiết cho sản phẩm 4 (Bình đun siêu tốc Philips)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(4, 2, 4, N'Bình đun nước nhanh chỉ khoảng 5 phút cho 1.5 lít. Tôi thích cơ chế tự ngắt an toàn khi nước sôi. Thiết kế nhỏ gọn, dễ cất giữ. Điểm trừ duy nhất là vỏ ngoài nóng lên khi đun nên cần cẩn thận.');

-- Thêm đánh giá ngắn cho sản phẩm 5 (Máy xay sinh tố Sunhouse)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(5, 4, 2, N'Máy kêu to và xay không mịn lắm.');

-- Thêm đánh giá dài cho sản phẩm 6 (Bếp từ đôi Sunhouse)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(6, 1, 5, N'Tôi rất hài lòng với bếp từ Sunhouse này sau 2 tháng sử dụng. Bếp có 2 vùng nấu riêng biệt với công suất khác nhau, cảm ứng nhiệt nhạy, mặt kính dễ lau chùi. Đặc biệt an toàn khi nhà có trẻ nhỏ vì không tỏa nhiệt ra xung quanh. Nhược điểm duy nhất là cần mua nồi chuyên dụng, nhưng đây là đặc điểm chung của bếp từ.');

-- Thêm đánh giá trung bình cho sản phẩm 7 (Máy lạnh Daikin 1HP)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(7, 3, 3, N'Máy lạnh chạy êm, làm lạnh nhanh nhưng tiêu thụ điện nhiều hơn quảng cáo. Dịch vụ lắp đặt của cửa hàng khá tốt.');

-- Thêm đánh giá ngắn cho sản phẩm 8 (Bình nóng lạnh Ariston 15L)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(8, 2, 4, N'Bình nóng lạnh tốt, giá hợp lý.');

-- Thêm đánh giá dài cho sản phẩm 17 (Robot hút bụi Xiaomi)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(17, 4, 5, N'Robot hút bụi Xiaomi là một trong những khoản đầu tư đáng giá nhất của tôi năm nay! Nó có thể lập bản đồ nhà, hút bụi và lau nhà tự động theo lịch trình qua app điện thoại. Đặc biệt ấn tượng với khả năng tránh vật cản và tự quay về trạm sạc khi hết pin. Nhược điểm duy nhất là giá hơi cao nhưng xứng đáng với công nghệ bạn nhận được.');

-- Thêm đánh giá trung bình cho sản phẩm 22 (Vòi sen tăng áp Inax)
INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES
(22, 1, 3, N'Vòi sen có nhiều chế độ phun khác nhau nhưng áp lực nước không ổn định lắm. Chất liệu nhựa cảm giác không bền bằng loại inox nhưng giá rẻ hơn.');


-- Bảng ProductSpecifications
CREATE TABLE ProductSpecifications (
    specification_id INT IDENTITY(1,1) PRIMARY KEY,
    product_id INT NOT NULL,
    brand NVARCHAR(100),
    origin NVARCHAR(100),
    warranty NVARCHAR(100),
    dimensions NVARCHAR(100),
    weight NVARCHAR(50),
    material NVARCHAR(255),
    power NVARCHAR(50),
    other_specs NVARCHAR(MAX),
    FOREIGN KEY (product_id) REFERENCES Products(product_id) ON DELETE CASCADE
);

INSERT INTO ProductSpecifications (product_id, brand, origin, warranty, dimensions, weight, material, power, other_specs) VALUES
(1, 'Panasonic', 'Nhật Bản', '24 tháng', '45x45x160 cm', '5.2 kg', 'Nhựa ABS, thép không gỉ', '45W', N'3 tốc độ gió, chế độ hẹn giờ 8 tiếng'),
