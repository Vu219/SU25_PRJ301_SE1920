/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.ProductSpecificationsDAO;
import model.ProductSpecificationsDTO;
import utils.AuthUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "ProductSpecificationsController", urlPatterns = {"/ProductSpecificationsController"})
public class ProductSpecificationsController extends HttpServlet {

    ProductSpecificationsDAO specsDAO = new ProductSpecificationsDAO();

    private static final String SPECS_FORM = "productSpecsForm.jsp";
    private static final String ERROR_PAGE = "error.jsp";
    private static final String LOGIN_PAGE = "login.jsp";
    private static final String PRODUCT_LIST = "ProductController?action=adminViewProducts";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR_PAGE;

        try {
            String action = request.getParameter("action");
            if (action == null || action.isEmpty()) {
                url = ERROR_PAGE;
                request.setAttribute("errorMessage", "Yêu cầu hành động");
            } else if ("viewSpecs".equals(action)) {
                url = handleViewSpecs(request, response);
            } else if ("editSpecs".equals(action)) {
                url = handleEditSpecs(request, response);
            } else if ("updateSpecs".equals(action)) {
                url = handleUpdateSpecs(request, response);
            } else if ("deleteSpecs".equals(action)) {
                url = handleDeleteSpecs(request, response);

            } else {
                request.setAttribute("errorMessage", "Hành động không hợp lệ");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi: " + e.getMessage());
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleViewSpecs(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));
            ProductSpecificationsDTO specs = specsDAO.getSpecificationsByProductId(productId);

            if (specs != null) {
                request.setAttribute("specs", specs);
                return SPECS_FORM;
            } else {
                request.setAttribute("errorMessage", "Không tìm thấy thông số kỹ thuật cho sản phẩm này");
                return ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi tải thông số kỹ thuật: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleEditSpecs(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Cần có quyền quản trị.");
            return ERROR_PAGE;
        }

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));
            ProductSpecificationsDTO specs = specsDAO.getSpecificationsByProductId(productId);

            if (specs == null) {
                specs = new ProductSpecificationsDTO();
                specs.setProduct_id(productId);
            }

            request.setAttribute("specs", specs);
            request.setAttribute("isEdit", true);
            return SPECS_FORM;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi tải thông số kỹ thuật: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleUpdateSpecs(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Cần có quyền quản trị.");
            return ERROR_PAGE;
        }

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));

            ProductSpecificationsDTO specs = new ProductSpecificationsDTO();
            specs.setProduct_id(productId);
            specs.setBrand(request.getParameter("brand"));
            specs.setOrigin(request.getParameter("origin"));
            specs.setWarranty(request.getParameter("warranty"));
            specs.setDimensions(request.getParameter("dimensions"));
            specs.setWeight(request.getParameter("weight"));
            specs.setMaterial(request.getParameter("material"));
            specs.setPower(request.getParameter("power"));
            specs.setOther_specs(request.getParameter("other_specs"));

            boolean success = specsDAO.saveOrUpdateSpecs(specs);
            if (success) {
                request.setAttribute("message", "Cập nhật thông số kỹ thuật thành công!");
            } else {
                request.setAttribute("errorMessage", "Cập nhật thông số kỹ thuật thất bại");
            }

            request.setAttribute("specs", specs);
            request.setAttribute("isEdit", true);          
            return SPECS_FORM;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi cập nhật thông số kỹ thuật: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleDeleteSpecs(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Cần có quyền quản trị.");
            return ERROR_PAGE;
        }

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));

            boolean success = specsDAO.deleteSpecs(productId);
            if (success) {
                request.setAttribute("message", "Xóa thông số kỹ thuật thành công!");
                return PRODUCT_LIST;
            } else {
                request.setAttribute("message", "Xóa thông số kỹ thuật thất bại!");
                return PRODUCT_LIST;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi trong khi xóa thông số kỹ thuật: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

}
