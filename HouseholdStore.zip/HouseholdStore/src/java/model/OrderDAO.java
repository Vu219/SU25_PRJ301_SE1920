/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import controller.OrderController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class OrderDAO {

    private static final String CREATE_ORDER = "INSERT INTO Orders (user_id, status, total_amount, payment_method, shipping_method, shipping_fee) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String CREATE_ORDER_DETAIL = "INSERT INTO OrderDetails (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    private static final String GET_ORDERS_BY_USER = "SELECT o.* FROM Orders o WHERE o.user_id = ? ORDER BY o.order_date DESC";
    private static final String GET_ORDER_DETAILS = "SELECT od.*, p.name as product_name FROM OrderDetails od JOIN Products p ON od.product_id = p.product_id WHERE od.order_id = ?";
    private static final String GET_ORDER_BY_ID = "SELECT * FROM Orders WHERE order_id = ?";
    private static final String CLEAR_CART = "DELETE FROM CartItems WHERE user_id = ?";
    private static final String UPDATE_ORDER_STATUS = "UPDATE Orders SET status = ? WHERE order_id = ?";
    private static final String UPDATE_PRODUCT_STOCK = "UPDATE Products SET stock_quantity = stock_quantity - ? WHERE product_id = ?";

    public int createOrder(OrderDTO order, List<CartItemDTO> cartItems) throws SQLException, Exception {
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement psDetail = null;
        ResultSet rs = null;
        int orderId = -1;

        try {
            conn = DbUtils.getConnection();
            conn.setAutoCommit(false); 

            ps = conn.prepareStatement(CREATE_ORDER, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, order.getUser_id());
            ps.setString(2, order.getStatus());
            ps.setDouble(3, order.getTotal_amount());
            ps.setString(4, order.getPayment_method());
            ps.setString(5, order.getShipping_method());
            ps.setDouble(6, order.getShipping_fee());
            ps.executeUpdate();

            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                orderId = rs.getInt(1);
            }

            if (orderId != -1 && cartItems != null) {
                psDetail = conn.prepareStatement(CREATE_ORDER_DETAIL);
                for (CartItemDTO item : cartItems) {
                    psDetail.setInt(1, orderId);
                    psDetail.setInt(2, item.getProduct_id());
                    psDetail.setInt(3, item.getQuantity());
                    psDetail.setDouble(4, item.getPrice());
                    psDetail.addBatch();
                }
                psDetail.executeBatch();

                psDetail = conn.prepareStatement(CLEAR_CART);
                psDetail.setInt(1, order.getUser_id());
                psDetail.executeUpdate();
            }

            PreparedStatement psUpdateStock = conn.prepareStatement(UPDATE_PRODUCT_STOCK);

            for (CartItemDTO item : cartItems) {
                psUpdateStock.setInt(1, item.getQuantity());
                psUpdateStock.setInt(2, item.getProduct_id());
                psUpdateStock.addBatch();
            }
            psUpdateStock.executeBatch();

            conn.commit(); 
            return orderId;
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    System.err.println("Error rolling back: " + ex.getMessage());
                }
            }
            throw e; 
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); 
                } catch (SQLException e) {
                    System.err.println("Error resetting auto-commit: " + e.getMessage());
                }
            }
            closeResources(conn, ps, rs);
            if (psDetail != null) {
                try {
                    psDetail.close();
                } catch (SQLException e) {
                    System.err.println("Error closing psDetail: " + e.getMessage());
                }
            }
        }
    }

    public List<OrderDTO> getOrdersByUser(int userId) throws SQLException {
        List<OrderDTO> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ORDERS_BY_USER);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            while (rs.next()) {
                OrderDTO order = new OrderDTO();
                order.setOrder_id(rs.getInt("order_id"));
                order.setUser_id(rs.getInt("user_id"));
                order.setOrder_date(rs.getTimestamp("order_date"));
                order.setStatus(rs.getString("status"));
                order.setTotal_amount(rs.getDouble("total_amount"));
                order.setPayment_method(rs.getString("payment_method"));
                orders.add(order);
            }
        } catch (Exception e) {
            System.err.println("Error in getOrdersByUser(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return orders;
    }

    public OrderDTO getOrderById(int orderId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        OrderDTO order = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ORDER_BY_ID);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                order = new OrderDTO();
                order.setOrder_id(rs.getInt("order_id"));
                order.setUser_id(rs.getInt("user_id"));
                order.setOrder_date(rs.getTimestamp("order_date"));
                order.setStatus(rs.getString("status"));
                order.setTotal_amount(rs.getDouble("total_amount"));
                order.setPayment_method(rs.getString("payment_method"));
            }
        } catch (Exception e) {
            System.err.println("Error in getOrderById(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return order;
    }

    public List<OrderDetailDTO> getOrderDetails(int orderId) throws SQLException {
        List<OrderDetailDTO> details = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ORDER_DETAILS);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            while (rs.next()) {
                OrderDetailDTO detail = new OrderDetailDTO();
                detail.setOrder_detail_id(rs.getInt("order_detail_id"));
                detail.setOrder_id(rs.getInt("order_id"));
                detail.setProduct_id(rs.getInt("product_id"));
                detail.setProductName(rs.getString("product_name"));
                detail.setQuantity(rs.getInt("quantity"));
                detail.setPrice(rs.getDouble("price"));
                details.add(detail);
            }
        } catch (Exception e) {
            System.err.println("Error in getOrderDetails(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return details;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Error closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public boolean updateOrderStatus(int orderId, String status) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(UPDATE_ORDER_STATUS);
            ps.setString(1, status);
            ps.setInt(2, orderId);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in updateOrderStatus(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean hasUserReviewedProduct(int userId, int productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM ProductReviews WHERE user_id = ? AND product_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error in hasUserReviewedProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return false;
    }

    public int countUserPurchasedProduct(int userId, int productId) throws SQLException {
        String sql = "SELECT COUNT(DISTINCT o.order_id) FROM Orders o "
                + "JOIN OrderDetails od ON o.order_id = od.order_id "
                + "WHERE o.user_id = ? AND od.product_id = ? "
                + "AND o.status = ?";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            ps.setString(3, OrderController.STATUS_COMPLETED);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (Exception e) {
            System.err.println("Error in countUserPurchasedProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return 0;
    }

}
