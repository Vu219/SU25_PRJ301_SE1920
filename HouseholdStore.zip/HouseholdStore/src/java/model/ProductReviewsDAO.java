/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class ProductReviewsDAO {

    private static final String INSERT_REVIEW = "INSERT INTO ProductReviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)";
    private static final String GET_REVIEWS_BY_PRODUCT = "SELECT r.*, u.username FROM ProductReviews r JOIN Users u ON r.user_id = u.user_id WHERE product_id = ? ORDER BY created_at DESC";
    private static final String COUNT_REVIEWS_BY_PRODUCT = "SELECT COUNT(*) FROM ProductReviews WHERE product_id = ?";

    public boolean addReview(ProductReviewsDTO review) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(INSERT_REVIEW);

            ps.setInt(1, review.getProduct_id());
            ps.setInt(2, review.getUser_id());
            ps.setInt(3, review.getRating());
            ps.setString(4, review.getComment());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, ps, null);
        }
    }

    public List<ProductReviewsDTO> getReviewsByProduct(int product_id) {
        List<ProductReviewsDTO> reviews = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_REVIEWS_BY_PRODUCT);
            ps.setInt(1, product_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                ProductReviewsDTO review = new ProductReviewsDTO();
                review.setReview_id(rs.getInt("review_id"));
                review.setProduct_id(rs.getInt("product_id"));
                review.setUser_id(rs.getInt("user_id"));
                review.setRating(rs.getInt("rating"));
                review.setComment(rs.getString("comment"));
                review.setCreated_at(rs.getTimestamp("created_at"));
                review.setUsername(rs.getString("username"));
                reviews.add(review);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return reviews;
    }

    public int countReviewsByProduct(int product_id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(COUNT_REVIEWS_BY_PRODUCT);
            ps.setInt(1, product_id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return 0;
    }

    public boolean deleteReview(int review_id) {
        String sql = "DELETE FROM ProductReviews WHERE review_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, review_id);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, ps, null);
        }
    }

    public ProductReviewsDTO getReviewById(int review_id) {
        String sql = "SELECT * FROM ProductReviews WHERE review_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, review_id);
            rs = ps.executeQuery();

            if (rs.next()) {
                ProductReviewsDTO review = new ProductReviewsDTO();
                review.setReview_id(rs.getInt("review_id"));
                review.setProduct_id(rs.getInt("product_id"));
                review.setUser_id(rs.getInt("user_id"));
                review.setRating(rs.getInt("rating"));
                review.setComment(rs.getString("comment"));
                review.setCreated_at(rs.getTimestamp("created_at"));
                return review;
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return null;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Error closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public int countUserReviewsForProduct(int userId, int productId) {
        String sql = "SELECT COUNT(*) FROM ProductReviews WHERE user_id = ? AND product_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        } finally {
            closeResources(conn, ps, rs);
        }
    }

    public boolean updateReview(ProductReviewsDTO review) {
        String sql = "UPDATE ProductReviews SET rating = ?, comment = ? WHERE review_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, review.getRating());
            ps.setString(2, review.getComment());
            ps.setInt(3, review.getReview_id());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, ps, null);
        }
    }
}
