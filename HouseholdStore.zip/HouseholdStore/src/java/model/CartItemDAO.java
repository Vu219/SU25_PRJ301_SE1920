/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class CartItemDAO {

    private static final String ADD_TO_CART = "INSERT INTO CartItems (user_id, product_id, quantity) VALUES (?, ?, ?)";
    private static final String UPDATE_CART_ITEM = "UPDATE CartItems SET quantity = ? WHERE cart_item_id = ?";
    private static final String REMOVE_FROM_CART = "DELETE FROM CartItems WHERE cart_item_id = ?";
    private static final String GET_CART_ITEMS = "SELECT ci.cart_item_id, ci.user_id, ci.product_id, p.name as product_name, p.price, ci.quantity, p.stock_quantity "
            + "FROM CartItems ci JOIN Products p ON ci.product_id = p.product_id "
            + "WHERE ci.user_id = ?";
    private static final String GET_CART_ITEM_BY_USER_AND_PRODUCT = "SELECT * FROM CartItems WHERE user_id = ? AND product_id = ?";
    private static final String GET_TOTAL_PRICE = "SELECT SUM(p.price * ci.quantity) as total "
            + "FROM CartItems ci JOIN Products p ON ci.product_id = p.product_id "
            + "WHERE ci.user_id = ?";

    public boolean addToCart(CartItemDTO cartItem) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();

            CartItemDTO existingItem = getCartItemByUserAndProduct(cartItem.getUser_id(), cartItem.getProduct_id());

            if (existingItem != null) {
                existingItem.setQuantity(existingItem.getQuantity() + cartItem.getQuantity());
                success = updateCartItem(existingItem);
            } else {
                ps = conn.prepareStatement(ADD_TO_CART);
                ps.setInt(1, cartItem.getUser_id());
                ps.setInt(2, cartItem.getProduct_id());
                ps.setInt(3, cartItem.getQuantity());
                success = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            System.err.println("Error in addToCart(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean updateCartItem(CartItemDTO cartItem) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(UPDATE_CART_ITEM);
            ps.setInt(1, cartItem.getQuantity());
            ps.setInt(2, cartItem.getCartItemId());

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in updateCartItem(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean removeFromCart(int cartItemId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(REMOVE_FROM_CART);
            ps.setInt(1, cartItemId);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in removeFromCart(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public List<CartItemDTO> getCartItems(int userId) throws SQLException {
        List<CartItemDTO> cartItems = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_CART_ITEMS);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            while (rs.next()) {
                CartItemDTO item = new CartItemDTO();
                item.setCartItemId(rs.getInt("cart_item_id"));
                item.setUser_id(rs.getInt("user_id"));
                item.setProduct_id(rs.getInt("product_id"));
                item.setProductName(rs.getString("product_name"));
                item.setPrice(rs.getDouble("price"));
                item.setQuantity(rs.getInt("quantity"));
                item.setTotalPrice(item.getTotalPrice());
                item.setStockQuantity(rs.getInt("stock_quantity"));

                cartItems.add(item);
            }
        } catch (Exception e) {
            System.err.println("Error in getCartItems(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return cartItems;
    }

    public double getTotalPrice(int userId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        double total = 0;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_TOTAL_PRICE);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                total = rs.getDouble("total");
            }
        } catch (Exception e) {
            System.err.println("Error in getTotalPrice(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return total;
    }

    public CartItemDTO getCartItemByUserAndProduct(int userId, int productId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        CartItemDTO item = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_CART_ITEM_BY_USER_AND_PRODUCT);
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                item = new CartItemDTO();
                item.setCartItemId(rs.getInt("cart_item_id"));
                item.setUser_id(rs.getInt("user_id"));
                item.setProduct_id(rs.getInt("product_id"));
                item.setQuantity(rs.getInt("quantity"));
            }
        } catch (Exception e) {
            System.err.println("Error in getCartItemByUserAndProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return item;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
